package Controller;
/**
 * Allows the user to edit an appointment using the AppointmentDB class to modify the DB
 */

import Model.Appointment;
import Model.Contact;
import Utility.AppointmentDB;
import Utility.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.TimeZone;
import java.util.logging.Logger;

/**
 * This class creates a view where appointments can be edited
 */

public class EditAppointment implements Initializable {
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    Long offsetToUTC = (long) (ZonedDateTime.now().getOffset()).getTotalSeconds();

    @FXML
    private TextField aptIDTextField;

    @FXML
    private TextField aptTitleTextField;

    @FXML
    private TextField aptDescriptionTextField;

    @FXML
    private TextField aptLocationTextField;

    @FXML
    private TextField aptTypeTextField;

    @FXML
    private TextField aptCreateByTextField;

    @FXML
    private TextField aptLastUpdateByTextField;

    @FXML
    private TextField aptCustomerIDTextField;

    @FXML
    private TextField aptUIDTextField;

    @FXML
    private TextField aptContactIDTextField;

    @FXML
    private Button editAptButton;

    @FXML
    private Button exitButton;

    @FXML
    private TextField aptStartTextField;

    @FXML
    private TextField aptEndTextField;

    @FXML
    private TextField aptCreateDateTextField;

    @FXML
    private TextField aptLastUpdateTextField;

    @FXML
    private ComboBox<Contact> contactNameComboBox;
    ObservableList<Contact> contactList = FXCollections.observableArrayList();

    /**
     * This method converts country cbjects into Strings for country selection
     * @throws SQLException
     */
    public EditAppointment() throws SQLException {

        try {
            Connection conn = DBConnection.startConnection();
            ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM contacts");
            while (rs.next()) {

                contactList.add(new Contact(rs.getInt("Contact_ID"),rs.getString("Contact_Name"),rs.getString("Email")));

            }
        } catch (SQLException ce) {
            Logger.getLogger(ce.toString());
        }
    }

    @FXML
    private void onActionSetContactID(ActionEvent event) throws IOException {

    }

    /**
     * This method sets the fields based on selection from the tableview in the Appointment Main scene
     * @see AppointmentMain#onActionSceneEditApt(ActionEvent)
     * @param modifyAppointment
     */

    @FXML
    public void sendAppointment(Appointment modifyAppointment)
    {
        aptIDTextField.setText(String.valueOf(modifyAppointment.getAppointmentID()));
        aptTitleTextField.setText(modifyAppointment.getTitle());
        aptDescriptionTextField.setText(modifyAppointment.getDescription());
        aptLocationTextField.setText(modifyAppointment.getLocation());
        aptTypeTextField.setText(modifyAppointment.getType());
        aptStartTextField.setText(modifyAppointment.getStart().format(formatter));
        aptEndTextField.setText(modifyAppointment.getEnd().format(formatter));
        aptLastUpdateByTextField.setText(modifyAppointment.getLastUpdatedBy());
        aptLastUpdateTextField.setText(modifyAppointment.getLastUpdate().format(formatter));
        aptCreateByTextField.setText(modifyAppointment.getCreatedBy());
        aptCreateDateTextField.setText(modifyAppointment.getCreateDate().format(formatter));
        aptCustomerIDTextField.setText(String.valueOf(modifyAppointment.getCustomerID()));
        aptUIDTextField.setText(String.valueOf(modifyAppointment.getUserID()));
        aptContactIDTextField.setText(String.valueOf(modifyAppointment.getContactID()));
        int comboBoxPreset = modifyAppointment.getContactID();
        Contact c = new Contact(comboBoxPreset);
        contactNameComboBox.setValue(c);
    }

    @FXML
    void onActionSceneMain(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/AppointmentMain.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    /**
     * This method gets the contact object and sets the Id text field based on name selection in combobox
     * @param event
     */
    @FXML
    void onActionFillContactID(ActionEvent event) {
        if (contactNameComboBox.getSelectionModel().isEmpty()) {
        }
        else {
            Contact c = contactNameComboBox.getSelectionModel().getSelectedItem();
            aptContactIDTextField.setText(String.valueOf(c.getContactID()));
        }
    }

    /**
     * This method sends the edited appointment to the database
     * @see AppointmentDB#editAppointment(Integer, String, String, String, String, LocalDateTime, LocalDateTime, LocalDateTime, String, LocalDateTime, String, Integer, Integer, Integer)
     * @param event
     * @return
     * @throws SQLException
     * @throws IOException
     */
    @FXML
    boolean onActionEditApt(ActionEvent event) throws SQLException, IOException{
        TimeZone est = TimeZone.getTimeZone("America/New York");
        Long offsetToEST = (long) (est.getOffset(new Date().getTime()) / 1000 / 60);
        LocalDateTime startTime = LocalDateTime.parse(aptStartTextField.getText(), formatter).minus(Duration.ofSeconds(offsetToUTC));

        //Sets the start time to EST

        startTime = startTime.plus(Duration.ofMinutes(offsetToEST));

        //Gets the time entered (user local) and set it to utc

        LocalDateTime endTime = LocalDateTime.parse(aptEndTextField.getText(), formatter).minus(Duration.ofSeconds(offsetToUTC));

        //Sets the end time to EST

        endTime = endTime.plus(Duration.ofMinutes(offsetToEST));

        //Compares the startTime and endTime between business hours of 8-22


        LocalTime businessHoursStart = LocalTime.of(8, 00);
        LocalTime businessHoursEnd = LocalTime.of(22, 00);

        //Checks if date time falls between other scheduled appointments

        LocalDateTime startDateTime = LocalDateTime.parse(aptStartTextField.getText(), formatter);
        LocalDateTime endDateTime = LocalDateTime.parse(aptEndTextField.getText(), formatter);
       try {
           //verifies that all fields are filled, otherwise gives an alert to enter fields

           if (aptTitleTextField.getText().isEmpty() || aptDescriptionTextField.getText().isEmpty() || aptLocationTextField.getText().isEmpty() || aptTypeTextField.getText().isEmpty() || aptStartTextField.getText().isEmpty() || aptEndTextField.getText().isEmpty() || aptCreateDateTextField.getText().isEmpty() || aptCreateByTextField.getText().isEmpty() || aptLastUpdateTextField.getText().isEmpty() || aptLastUpdateByTextField.getText().isEmpty() || aptCustomerIDTextField.getText().isEmpty() || aptCustomerIDTextField.getText().isEmpty() || aptContactIDTextField.getText().isEmpty()) {
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("ERROR");
               alert.setContentText("Please ensure all fields are filled");
               alert.showAndWait();
           }


           //Checks for overlapping appointment times
           for (Appointment appointment : AppointmentDB.allAppointments) {
               if((startDateTime.isEqual(appointment.getStart()) || startDateTime.isAfter(appointment.getStart()) && startDateTime.isBefore(appointment.getEnd()))) {
                   Alert alert = new Alert(Alert.AlertType.ERROR);
                   alert.setTitle("ERROR");
                   alert.setContentText("Please enter a time for an appointment start and end time that is not already taken");
                   alert.showAndWait();
                   return false;
               }
           }

           //Checks if time of start and end are within the business hours
           if (startTime.toLocalTime().isBefore(businessHoursStart) || endTime.toLocalTime().isAfter(businessHoursEnd)) {
               Alert alert = new Alert(Alert.AlertType.ERROR);
               alert.setTitle("ERROR");
               alert.setContentText("Time entered must be between the business hours of 0800 EST and 1000 EST");
               alert.showAndWait();

           }

           //If the fields are not blank, this sends the Appointment object to database
           else if (!aptTitleTextField.equals("") && !aptTypeTextField.equals("") && !aptDescriptionTextField.equals("") && !aptLocationTextField.equals("")){
               FXMLLoader loader = new FXMLLoader();
               loader.setLocation(getClass().getResource("/View/AppointmentMain.fxml"));
               Parent parent = loader.load();

               Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
               Parent scene = loader.getRoot();
               stage.setScene(new Scene(scene));
               stage.show();

               return AppointmentDB.editAppointment(Integer.valueOf(
                       aptIDTextField.getText()),
                       aptTitleTextField.getText(),
                       aptDescriptionTextField.getText(),
                       aptLocationTextField.getText(),
                       aptTypeTextField.getText(),
                       LocalDateTime.parse(aptStartTextField.getText(), formatter).minus(Duration.ofSeconds(offsetToUTC)),
                       LocalDateTime.parse(aptEndTextField.getText(), formatter).minus(Duration.ofSeconds(offsetToUTC)),
                       LocalDateTime.parse(aptCreateDateTextField.getText(), formatter).minus(Duration.ofSeconds(offsetToUTC)),
                       aptCreateByTextField.getText(),
                       LocalDateTime.parse(aptLastUpdateTextField.getText(), formatter).minus(Duration.ofSeconds(offsetToUTC)),
                       aptLastUpdateByTextField.getText(),
                       Integer.valueOf(aptCustomerIDTextField.getText()),
                       Integer.valueOf(aptUIDTextField.getText()),
                       Integer.valueOf(aptContactIDTextField.getText()));
           }
       }
       /**
        * @exception DateTimeParseException e if date time fields are not formatted correctly this is caught to alert the user to modify them correctly
        */
        catch (DateTimeParseException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setContentText("Date and time fields must be in format: YYYY-MM-DD HH:MM");
            alert.showAndWait();
            return false;
        }
       return false;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        contactNameComboBox.setItems(contactList);

    }
}

