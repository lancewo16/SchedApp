package Controller;

import Model.Appointment;
import Utility.AppointmentDB;
import Utility.DBConnection;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.Month;
import java.util.ResourceBundle;

/**
 * This class creates a controller of the Tableview report containing the selected customer's appointments
 */

public class CustomerAppointmentsReportController implements Initializable {

    @FXML
    private Button menuButton;

    @FXML
    private Button exitButton;

    @FXML
    private TextField numberJanTextField;

    @FXML
    private TextField numberFebTextField;

    @FXML
    private TextField numberMarTextField;

    @FXML
    private TextField numberAprilTextField;

    @FXML
    private TextField numberMayTextField;

    @FXML
    private TextField numberJuneTextField;

    @FXML
    private TextField numberJulyTextField;

    @FXML
    private TextField numberAugTextField;

    @FXML
    private TextField numberSeptTextField;

    @FXML
    private TextField numberOctTextField;

    @FXML
    private TextField numberNovTextField;

    @FXML
    private TextField numberDecTextField;

    @FXML
    private TextField planningTextField;

    @FXML
    private Button logoutButton;

    @FXML
    private TextField deBriefingTextField;


    @FXML
    void onActionExitApp(ActionEvent event) {
        Button sourceButton = (Button) event.getSource();
        exitButton.setText(sourceButton.getText());
        DBConnection.closeConnection();
        System.exit(0);
    }

    @FXML
    void onActionSceneMain(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/View/MainMenu.fxml"));
        loader.load();

        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Parent scene = loader.getRoot();
        stage.setScene(new Scene(scene));
        stage.show();
    }

    @FXML
    void onActionSceneLogout(ActionEvent event) throws IOException {
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        Object scene = FXMLLoader.load(getClass().getResource("/View/Login.fxml"));
        stage.setScene(new Scene((Parent) scene));
        stage.show();
    }

    @FXML
    public void initialize(URL url, ResourceBundle resourceBundle) {
        try {
            int planningSessionCount = 0;
            int deBrief = 0;
            int janCount = 1;
            int febCount = 1;
            int marCount = 1;
            int aprCount = 1;
            int mayCount = 1;
            int junCount = 1;
            int julCount = 1;
            int augCount = 1;
            int sepCount = 1;
            int octCount = 1;
            int novCount = 1;
            int decCount = 1;
            for (Appointment appointment : AppointmentDB.allAppointments) {
                String aptType = appointment.getType();
                {
                    if (aptType.contains("Planning Session") ) {
                        planningSessionCount = planningSessionCount +1;
                        planningTextField.setText(String.valueOf(planningSessionCount));
                    } else if (aptType.contains("De-Briefing")) {
                        deBrief = deBrief +1;
                        deBriefingTextField.setText(String.valueOf(deBrief));
                    }
                }


            }
            for (Appointment appointment : AppointmentDB.allAppointments) {
                Month aptStart = appointment.getStart().getMonth();
                if (aptStart == Month.JANUARY) {
                    janCount = janCount + 1;
                    numberJanTextField.setText(String.valueOf(janCount));

                } else if (aptStart == Month.FEBRUARY) {
                    febCount = febCount + 1;
                    numberFebTextField.setText(String.valueOf(febCount));

                } else if (aptStart == Month.MARCH) {
                    marCount = marCount + 1;
                    numberMarTextField.setText(String.valueOf(marCount));

                } else if (aptStart == Month.APRIL) {
                    aprCount = aprCount + 1;
                    numberAprilTextField.setText(String.valueOf(aprCount));
                } else if (aptStart == Month.MAY) {
                    mayCount = mayCount + 1;
                    numberMayTextField.setText(String.valueOf(mayCount));
                } else if (aptStart == Month.JUNE) {
                    junCount = junCount + 1;
                    numberJuneTextField.setText(String.valueOf(junCount));
                } else if (aptStart == Month.JULY) {
                    julCount = julCount + 1;
                    numberJulyTextField.setText(String.valueOf(julCount));
                } else if (aptStart == Month.AUGUST) {
                    augCount = augCount + 1;
                    numberAugTextField.setText(String.valueOf(augCount));
                } else if (aptStart == Month.SEPTEMBER) {
                    sepCount = sepCount + 1;
                    numberSeptTextField.setText(String.valueOf(sepCount));

                } else if (aptStart == Month.OCTOBER) {
                    octCount++;
                    numberOctTextField.setText(String.valueOf(octCount));

                } else if (aptStart == Month.NOVEMBER) {
                    novCount = novCount + 1;
                    numberNovTextField.setText(String.valueOf(novCount));

                } else if (aptStart == Month.DECEMBER) {
                    decCount = decCount + 1;
                    numberDecTextField.setText(String.valueOf(decCount));

                }
                return;

            }

            AppointmentDB.getAllAppointments();



        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
